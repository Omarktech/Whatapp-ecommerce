<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // For local testing, remove in production if needed

$productsJson = file_get_contents('../products.json'); // Path to products.json, assuming it's one level up from 'api' folder

if ($productsJson === false) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Could not read products.json']);
    exit;
}

$products = json_decode($productsJson, true);

if ($products === null && json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Error decoding products.json', 'jsonError' => json_last_error_msg()]);
    exit;
}

if ($products === null) {
    $products = []; // Handle case where products.json might be empty or invalid JSON but not throw a JSON error
}


echo json_encode($products);
?>